package com.example.proyectosia_aulavirtual;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;


//Se crea la clase Institucion
public class Institucion{
    private String nombreInstitucion;
    private ArrayList<Curso> cursos;
    private ArrayList<Profesor> profesores;

//SE CREA EL CONSTRUCTOR DE LA CLASE INSTITUCION
    public Institucion(String nombreInstitucion) throws IOException {
        this.nombreInstitucion = nombreInstitucion;
        this.cursos = new ArrayList<>();
        this.profesores = new ArrayList<>();
        // Crear archivos CSV si no existen
        CSVUtil.createCSVIfNotExists("cursos.csv", "ID,Nombre");
        CSVUtil.createCSVIfNotExists("alumnos.csv", "Nombre,Apellido,Edad,RUT,IdCursoAlQuePertenece");
        CSVUtil.createCSVIfNotExists("profesores.csv", "Nombre,Apellido,Edad,RUT");
        CSVUtil.createCSVIfNotExists("recursos.csv", "ID,Nombre,RutProfesor,DescRec,CursoAlQuePertenece");

        cargarDatosDesdeCSV();
    }
//SE CREAN LOS METODOS GETTER Y SETTER DE LA CLASE INSTITUCION
    public void setNombreInstitucion(String nombreInstitucion){
        this.nombreInstitucion = nombreInstitucion;
    }

    public String getNombreInstitucion(){
        return nombreInstitucion;
    }

    public void agregarCurso(Curso curso)throws IOException{
        this.cursos.add(curso);

    }

    public void agregarProfesor(Profesor profesor)throws IOException{
        this.profesores.add(profesor);
        if(!CSVUtil.rutExistsInCSV("profesores.csv", profesor.getRut())){
            CSVUtil.appendToCSV("profesores.csv", profesor.toCSV());
        }
    }

    public void setCursos(ArrayList<Curso> cursos){
        this.cursos = cursos;
    }

    public ArrayList<Curso> getCursos(){
        return cursos;
    }

    public void setProfesores(ArrayList<Profesor> profesores){
        this.profesores = profesores;
    }

    public ArrayList<Profesor> getProfesores(){
        return profesores;
    }

    public Profesor buscarProfesorPorRut(String rut){
        for(Profesor profesor : profesores){
            if(profesor.getRut().equals(rut)){
                return profesor;
            }
        }
        return null;
    }

    public Curso buscarCursoPorId(int idCurso){
        for(Curso curso : cursos){
            if(curso.getCursoId() == idCurso){
                return curso;
            }
        }
        return null;
    }

    public boolean existeCurso(String idCurso) {
        try {
            int id = Integer.parseInt(idCurso);
            for (Curso curso : cursos) {
                if (curso.getCursoId() == id) {
                    return true;
                }
            }
        } catch (NumberFormatException e) {
            System.out.println("El ID del curso debe ser un número entero.");
        }
        return false;
    }

    public boolean rutExisteEnMemoria(String rut) {
        return profesores.stream().anyMatch(profesor -> profesor.getRut().equals(rut));
    }

    public ArrayList<Alumno> getAlumnosDesdeCurso() {
        ArrayList<Alumno> AlumnosDesdeCurso = new ArrayList<>();
        for (Curso curso : cursos) {
            AlumnosDesdeCurso.addAll(curso.getAlumnos());
        }
        return AlumnosDesdeCurso;
    }

    // ***METODOS BUSCAR***

    //METODO BUSCAR CURSO POR ID Y POR NOMBRE 
    public Curso buscarCurso(String nombre)
    {
        for(Curso curso: cursos)
        {
            if(curso.getNombre().equalsIgnoreCase(nombre))
            {
                return curso;
            }
        }
        return null;
    }

    // ***METODOS ELIMINAR***


    //METODO ELIMINAR CURSO
    public void eliminarCurso(Curso curso){
        cursos.remove(curso);
    }


    public void eliminarProfesor(String rutProfesor) {
        profesores.removeIf(profesor -> profesor.getRut().equals(rutProfesor));
    }


// METODOS DEL CSV
    private void actualizarCSVRecursos() throws IOException {
        Set<Integer> idsRecursos = new HashSet<>();
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("recursos.csv"))) {
            writer.write("ID,Nombre,RutProfesor,DescRec,CursoAlQuePertenece");
            writer.newLine();
            
            for (Curso curso : cursos) {
                for (Recurso recurso : curso.getRecursos()) {
                    if (!idsRecursos.contains(recurso.getRecursoID())) {
                        writer.write(recurso.toCSV());
                        writer.newLine();
                        idsRecursos.add(recurso.getRecursoID());
                    }
                }
            }
        }
    }

    private void actualizarCSVRecursos(int cursoId, int recursoId) throws IOException {
        ArrayList<Recurso> recursosActualizados = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader("recursos.csv"))) {
            String line;
            br.readLine(); // Saltar la cabecera
            while ((line = br.readLine()) != null) {
                String[] values = line.split(",");
                if (values.length >= 5) {
                    int id = Integer.parseInt(values[0]);
                    int idCursoPerteneciente = Integer.parseInt(values[4]);
                    if (!(id == recursoId && idCursoPerteneciente == cursoId)) {
                        recursosActualizados.add(new Recurso( values[1],values[3] ,id ,buscarProfesorPorRut(values[2]) ,idCursoPerteneciente));
                    }
                }
            }
        }

        try (FileWriter writer = new FileWriter("recursos.csv")) {
            writer.append("ID,Nombre,RutProfesor,DescRec,CursoAlQuePertenece\n");
            for (Recurso recurso : recursosActualizados) {
                writer.append(String.valueOf(recurso.getRecursoID())).append(",")
                      .append(recurso.getNombreRecurso()).append(",")
                      .append(recurso.getProfesor().getRut()).append(",")
                      .append(recurso.getDescripcionRec()).append(",")
                      .append(String.valueOf(recurso.getIdCursoPerteneciente())).append("\n");
            }
        }
    }

    //metodo para actualizar CSV
    private void actualizarCSVProfesores() throws IOException {
        try (FileWriter writer = new FileWriter("profesores.csv")) {
            writer.append("Nombre,Apellido,Edad,RUT\n");
            for (Profesor profesor : profesores) {
                writer.append(profesor.toCSV());
                writer.append("\n");
            }
        }
    }
    private void actualizarCSVAlumnos(ArrayList<Alumno> alumnos) throws IOException {
        try (FileWriter writer = new FileWriter("alumnos.csv")) {
            writer.append("Nombre,Apellido,Edad,Rut,CursoPerteneciente\n");
            for (Alumno alumno : alumnos) {
                writer.append(alumno.getNombre()).append(",")
                      .append(alumno.getApellido()).append(",")
                      .append(String.valueOf(alumno.getEdad())).append(",")
                      .append(alumno.getRut()).append(",")
                      .append(String.valueOf(alumno.getIdCursoPerteneciente())).append("\n");
            }
        }
    }
// Aca se cargan todos los datos del csv y se agregan a RAM 
    public void cargarDatosDesdeCSV() throws IOException {
        // Cargar cursos
        try (BufferedReader br = new BufferedReader(new FileReader("cursos.csv"))) {
            String line;
            br.readLine(); // Saltar la cabecera
            while ((line = br.readLine()) != null) {
                String[] values = line.split(",");
                int id = Integer.parseInt(values[0]);
                String nombre = values[1];
                cursos.add(new Curso(id, nombre));
            }
        }

        // Cargar alumnos
        try (BufferedReader br = new BufferedReader(new FileReader("alumnos.csv"))) {
            String line;
            br.readLine(); // Saltar la cabecera
            while ((line = br.readLine()) != null) {
                String[] values = line.split(",");
                String nombre = values[0];
                String apellido = values[1];
                int edad = Integer.parseInt(values[2]);
                String rut = values[3];
                int idCurso = Integer.parseInt(values[4]);
                Alumno alumno = new Alumno(nombre, apellido, edad, rut, idCurso);

                // Aquí se agrega al alumno al curso correspondiente 
                for(Curso curso : cursos){
                    if(curso.getCursoId() == idCurso){
                        curso.agregarAlumnoACurso(alumno);
                    }
                }
        }
    }

        // Cargar profesores
        try (BufferedReader br = new BufferedReader(new FileReader("profesores.csv"))) {
            String line;
            br.readLine(); // Saltar la cabecera
            while ((line = br.readLine()) != null) {
                String[] values = line.split(",");
                String nombre = values[0];
                String apellido = values[1];
                int edad = Integer.parseInt(values[2]);
                String rut = values[3];
                profesores.add(new Profesor(nombre, apellido, edad, rut));
            }
        }

        try (BufferedReader br = new BufferedReader(new FileReader("recursos.csv"))) {
            String line;
            br.readLine(); // Saltar la cabecera
            while ((line = br.readLine()) != null) {
                String[] values = line.split(",");
                if (values.length < 5) {
                    continue; // Saltar líneas que no tienen suficientes campos
                }
    
                int id;
                try {
                    id = Integer.parseInt(values[0]);
                } catch (NumberFormatException e) {
                    id = -1; // Valor predeterminado o manejo de error
                }
    
                String nombre = values[1];
                String rutProfesor = values[2];
                String descripcion = values[3];
                int idCurso;
                try {
                    idCurso = Integer.parseInt(values[4]);
                } catch (NumberFormatException e) {
                    idCurso = -1; // Valor predeterminado o manejo de error
                }
    
                Profesor profesor = buscarProfesorPorRut(rutProfesor);
                Recurso recurso = new Recurso(nombre, descripcion, id, profesor, idCurso);
    
                // Aquí se agrega el recurso al curso correspondiente
                for (Curso curso : cursos) {
                    if (curso.getCursoId() == idCurso) {
                        curso.agregarRecurso(recurso);
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public Curso getCursoById(int id) {
        for (Curso curso : cursos) {
            if (curso.getCursoId() == id) {
                return curso;
            }
        }
        return null;
    }

    private ArrayList<Alumno> cargarAlumnosDesdeCSV() throws IOException {
        ArrayList<Alumno> alumnos = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader("alumnos.csv"))) {
            String line;
            br.readLine(); // Saltar la cabecera
            while ((line = br.readLine()) != null) {
                String[] values = line.split(",");
                if (values.length >= 4) {
                    String nombre = values[0];
                    String apellido = values[1];
                    int edad = Integer.parseInt(values[2]);
                    String rut = values[3];
                    int cursoId = Integer.parseInt(values[4]);
                    alumnos.add(new Alumno(nombre, apellido,edad,rut, cursoId));
                }
            }
        }
        return alumnos;
    }

}

