package com.example.proyectosia_aulavirtual;

import java.io.IOException;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class MostrarCursoController {
    private Institucion institucion;


    @FXML
    private Button btnVolverMenu;

    @FXML
    private TableView<Curso> tableCursos;

    @FXML
    private TableColumn<Curso, Integer> colID;

    @FXML
    private TableColumn<Curso, String> colNombreCurso;

    private ObservableList<Curso> cursosList;

    @FXML
    public void initialize() {
        colID.setCellValueFactory(new PropertyValueFactory<>("cursoId"));
        colNombreCurso.setCellValueFactory(new PropertyValueFactory<>("nombre"));

        cursosList = FXCollections.observableArrayList();

        tableCursos.setItems(cursosList);

        btnVolverMenu.setOnMouseEntered(event -> btnVolverMenu.setStyle("-fx-background-color: #002153;"));
        btnVolverMenu.setOnMouseExited(event -> btnVolverMenu.setStyle("-fx-background-color: #1d4e96;"));

        btnVolverMenu.setOnAction(event -> openWindow("Curso.fxml", "Menú Curso", btnVolverMenu));
    }
    
    public void mostrarCurso() {
        for (Curso curso : institucion.getCursos()) {
            cursosList.add(curso);
        }
    }

    private void openWindow(String fxmlFile, String title, Button button) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = fxmlLoader.load();
            Stage stage = new Stage();
            Object controller = fxmlLoader.getController();
            if(controller instanceof CursoController){
                ((CursoController) controller).setInstitucion(institucion);
            }
            stage.setTitle(title);
            stage.setScene(new Scene(root));
            stage.show();

            Stage currentStage = (Stage) button.getScene().getWindow();
            currentStage.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void setInstitucion(Institucion institucion) {
        this.institucion = institucion;
        mostrarCurso();
    }
}
