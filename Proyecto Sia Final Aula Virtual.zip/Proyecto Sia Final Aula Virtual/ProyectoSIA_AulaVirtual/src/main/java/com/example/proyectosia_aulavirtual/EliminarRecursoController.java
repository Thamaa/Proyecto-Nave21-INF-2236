package com.example.proyectosia_aulavirtual;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class EliminarRecursoController {
    private Institucion institucion;


    @FXML
    private Button btnVolverMenu;

    @FXML
    private Button btnEliminarRecurso;

    @FXML
    private TableView<Recurso> tablaRecursos;

    @FXML
    private TableColumn<Recurso, String> columnaID;

    @FXML
    private TableColumn<Recurso, String> columnaNombre;
    @FXML
    private TableColumn<Recurso, String> columnaIDCurso;


    @FXML
    private TextField inputRecursoID;

    private final ObservableList<Recurso> recursosData = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        // Configurar botones
        btnVolverMenu.setOnMouseEntered(event -> btnVolverMenu.setStyle("-fx-background-color: #002153;"));
        btnVolverMenu.setOnMouseExited(event -> btnVolverMenu.setStyle("-fx-background-color: #003380;"));

        btnEliminarRecurso.setOnMouseEntered(event -> btnEliminarRecurso.setStyle("-fx-background-color: #002153;"));
        btnEliminarRecurso.setOnMouseExited(event -> btnEliminarRecurso.setStyle("-fx-background-color:  #003380;"));
        btnVolverMenu.setOnAction(event -> openWindow("Recurso.fxml", "Ventana Recurso", btnVolverMenu));
        btnEliminarRecurso.setOnAction(event -> {
            try {
                eliminarRecurso();
            } catch (RecursoNoEncontradoExcep e) {
                mostrarAlerta("Error", e.getMessage());
            }
        });

        // Configurar tabla
        columnaID.setCellValueFactory(new PropertyValueFactory<>("recursoID"));
        columnaNombre.setCellValueFactory(new PropertyValueFactory<>("nombreRecurso"));
        columnaIDCurso.setCellValueFactory(new PropertyValueFactory<>("idCursoPerteneciente"));

        tablaRecursos.setItems(recursosData);
    }

    private void mostrarRecursos() {
        for (Curso cursos : institucion.getCursos()) {
            for (Recurso recurso : cursos.getRecursos()) {
                recursosData.add(recurso);
            }
        }
    }

    // Abre ventana anterior
    private void openWindow(String fxmlFile, String title, Button button) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = fxmlLoader.load();
            Stage stage = new Stage();
            Object controller = fxmlLoader.getController();
            if (controller instanceof RecursoController) {
                ((RecursoController) controller).setInstitucion(institucion);
            }
            stage.setTitle(title);
            stage.setScene(new Scene(root));
            stage.show();

            Stage currentStage = (Stage) button.getScene().getWindow();
            currentStage.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Función creada el 05-10-24
    private void eliminarRecurso() throws RecursoNoEncontradoExcep {
        // Obtener el ID del recurso a eliminar
        int idRecurso = Integer.parseInt(inputRecursoID.getText());

        // Buscar el recurso en los cursos de la institución
        for (Curso curso : institucion.getCursos()) {
            Recurso recurso = curso.buscarRecursoPorID(idRecurso);
            if (recurso != null) {
                // Eliminar el recurso del curso
                curso.eliminarRecursoDeCurso(recurso);

                // Actualizar el archivo CSV de recursos
                try {
                    actualizarCSVRecursos();
                    mostrarAlerta("Éxito", "Recurso eliminado exitosamente.");
                } catch (IOException e) {
                    mostrarAlerta("Error", "Ocurrió un error al actualizar el archivo CSV.");
                    e.printStackTrace();
                }
                return;
            }
        }
        throw new RecursoNoEncontradoExcep("No se encontró un recurso con el ID especificado.");
    }

    private void actualizarCSVRecursos() throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("recursos.csv"))) {
            writer.write("ID,Nombre,RutProfesor,DescRec,CursoAlQuePertenece");
            writer.newLine();
            for (Curso curso : institucion.getCursos()) {
                for (Recurso recurso : curso.getRecursos()) {
                    writer.write(recurso.toCSV());
                    writer.newLine();
                }
            }
        }
    }

    private void mostrarAlerta(String titulo, String mensaje) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }

    public void setInstitucion(Institucion institucion) {
        this.institucion = institucion;
        mostrarRecursos();
    }
}