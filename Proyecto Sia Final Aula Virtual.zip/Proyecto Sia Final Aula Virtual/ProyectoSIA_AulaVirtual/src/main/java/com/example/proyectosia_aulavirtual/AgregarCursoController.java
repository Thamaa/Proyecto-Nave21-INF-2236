package com.example.proyectosia_aulavirtual;

import java.io.IOException;
import java.util.List;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class AgregarCursoController {
    private Institucion institucion;

    public void setInstitucion(Institucion institucion) {
        this.institucion = institucion;
        // Inicializar el cursoIdLabel después de establecer la institucion
        inicializarCurso();
    }
    


    @FXML
    private Label cursoIdLabel;

    @FXML
    private TextField nombreCursoField;


    @FXML
    private Button registrarBtn;

    @FXML
    private Button volverBtn;



    @FXML
    public void initialize() {
        volverBtn.setOnMouseExited(event -> volverBtn.setStyle("-fx-background-color: #1d4e96;"));

        registrarBtn.setOnAction(event -> {
            try {
                registrarCurso();
            } catch (IOException e) {
                e.printStackTrace();
                mostrarAlerta("Error", "Ocurrió un error al registrar el curso.");
            }
        });

        volverBtn.setOnAction(event -> openWindow("Curso.fxml", "Menú Curso", volverBtn));
    }



    private void inicializarCurso() {
        if (institucion != null) {
            int nuevoCursoId = obtenerNuevoCursoId();
            cursoIdLabel.setText(String.valueOf(nuevoCursoId));
        } else {
            mostrarAlerta("Advertencia", "No se ha establecido la institución.");
        }
    }

    private int obtenerNuevoCursoId() {
        List<Curso> cursos = institucion.getCursos();
        if (cursos.isEmpty()) {
            return 1; // Si no hay cursos, el primer ID será 1
        } else {
            int ultimoCursoId = cursos.get(cursos.size() - 1).getCursoId();
            return ultimoCursoId + 1;
        }
    }

    private void registrarCurso() throws IOException {
        String nombreCurso = nombreCursoField.getText();
        if (nombreCurso.isEmpty()) {
            mostrarAlerta("Advertencia", "El nombre del curso no puede estar vacío.");
            return;
        }
    
        int nuevoCursoId = Integer.parseInt(cursoIdLabel.getText());
        Curso nuevoCurso = new Curso(nuevoCursoId, nombreCurso);
    
        // Agregar el curso a la memoria
        institucion.agregarCurso(nuevoCurso);
    
        // Actualizar el archivo CSV
        if (!CSVUtil.idExistsInCSV("cursos.csv", nuevoCursoId)) {
            CSVUtil.appendToCSV("cursos.csv", nuevoCurso.toCSV());
        }
    
        mostrarAlerta("Éxito", "Curso registrado exitosamente.");
    
        // Limpiar la casilla de texto
        nombreCursoField.setText("");
    }

    private void openWindow(String fxmlFile, String title, Button button) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = fxmlLoader.load();
            Stage stage = new Stage();
            Object controller = fxmlLoader.getController();
            if(controller instanceof CursoController){
                ((CursoController) controller).setInstitucion(institucion);
            }
            stage.setTitle(title);
            stage.setScene(new Scene(root));
            stage.show();
            // Cerrar la ventana actual
            Stage currentStage = (Stage) button.getScene().getWindow();
            currentStage.close();
        } catch (IOException e) {
            e.printStackTrace();
            mostrarAlerta("Error", "Ocurrió un error al abrir la ventana.");
        }
    }

    private void mostrarAlerta(String titulo, String mensaje) {
        Alert alerta = new Alert(Alert.AlertType.INFORMATION);
        alerta.setTitle(titulo);
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }
}



