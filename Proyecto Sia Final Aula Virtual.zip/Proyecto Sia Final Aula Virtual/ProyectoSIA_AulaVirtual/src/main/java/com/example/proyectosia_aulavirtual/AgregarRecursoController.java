package com.example.proyectosia_aulavirtual;

import java.io.IOException;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class AgregarRecursoController {
    private Institucion institucion;

    public void setInstitucion(Institucion institucion) {
        this.institucion = institucion;
        mostrarProfesores();
        mostrarCurso();
    }

    @FXML
    private TextField textFieldRutProfesor;

    @FXML
    private TextField textFieldIdCurso;

    @FXML
    private TextField textFieldIdRecurso;

    @FXML
    private TextField textFieldNombreRecurso;

    @FXML
    private TextField textFieldDescripcion;

    @FXML
    private TableView<Profesor> tablaProfesores;

    @FXML
    private TableColumn<Profesor, String> columnaRutProfesor;

    @FXML
    private TableColumn<Profesor, String> columnaNombreProfesor;

    @FXML
    private TableView<Curso> tablaCursos;

    @FXML
    private TableColumn<Curso, Integer> columnaIdCurso;

    @FXML
    private TableColumn<Curso, String> columnaNombreCurso;

    @FXML
    private Button buttonAgregarRecurso;

    @FXML
    private Button buttonVolverMenuRecurso;

    private final ObservableList<Profesor> profesoresData = FXCollections.observableArrayList();
    private final ObservableList<Curso> cursosData = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        // Configurar las columnas de la tabla de profesores
        columnaRutProfesor.setCellValueFactory(new PropertyValueFactory<>("rut"));
        columnaNombreProfesor.setCellValueFactory(new PropertyValueFactory<>("nombre"));

        // Configurar las columnas de la tabla de cursos
        columnaIdCurso.setCellValueFactory(new PropertyValueFactory<>("cursoId"));
        columnaNombreCurso.setCellValueFactory(new PropertyValueFactory<>("nombre"));



        // Añadir los datos a las tablas
        tablaProfesores.setItems(profesoresData);
        tablaCursos.setItems(cursosData);

        // Configurar eventos de los botones
        buttonVolverMenuRecurso.setOnMouseEntered(event -> buttonVolverMenuRecurso.setStyle("-fx-background-color: #002153;"));
        buttonVolverMenuRecurso.setOnMouseExited(event -> buttonVolverMenuRecurso.setStyle("-fx-background-color: #003380;"));
        buttonAgregarRecurso.setOnAction(event -> agregarRecurso());
        buttonVolverMenuRecurso.setOnAction(event -> openWindow("Recurso.fxml", "Ventana Recurso", buttonVolverMenuRecurso));
    }

    public void mostrarProfesores(){
        for (Profesor profesor : institucion.getProfesores()) {
            profesoresData.add(profesor);
        }
    }

    public void mostrarCurso() {
        for (Curso curso : institucion.getCursos()) {
            cursosData.add(curso);
        }
    }

    public void agregarRecurso() {
        try {
            String nombreRecurso = textFieldNombreRecurso.getText();
            String descripcionRecurso = textFieldDescripcion.getText();
            String rutProfesor = textFieldRutProfesor.getText();
            int idCurso = Integer.parseInt(textFieldIdCurso.getText());
            int idRecurso = Integer.parseInt(textFieldIdRecurso.getText());

            // Validar que el ID del recurso no exista en ningún otro curso
            if (idRecursoExisteEnMemoria(idRecurso)) {
                mostrarAlerta("Error", "El ID del recurso ya existe en otro curso.");
                return;
            }

            Profesor profesor = institucion.buscarProfesorPorRut(rutProfesor);
            if (profesor == null) {
                mostrarAlerta("Error", "No se encontró un profesor con el RUT especificado.");
                return;
            }

            Curso curso = institucion.buscarCursoPorId(idCurso);
            if (curso == null) {
                mostrarAlerta("Error", "No se encontró un curso con el ID especificado.");
                return;
            }

            Recurso nuevoRecurso = new Recurso(nombreRecurso, descripcionRecurso, idRecurso, profesor, idCurso);

            // Agregar el recurso a la memoria
            curso.agregarRecursoACurso(nuevoRecurso);

            // Actualizar el archivo CSV
            if (!CSVUtil.idExistsInCSV("recursos.csv", idRecurso)) {
                CSVUtil.appendToCSV("recursos.csv", nuevoRecurso.toCSV());
            }

            mostrarAlerta("Éxito", "Recurso agregado exitosamente.");
            limpiarCampos();
        } catch (NumberFormatException e) {
            mostrarAlerta("Error", "El ID del curso y el ID del recurso deben ser números.");
        } catch (IOException e) {
            mostrarAlerta("Error", "Ocurrió un error al agregar el recurso.");
        }
    }

    private boolean idRecursoExisteEnMemoria(int idRecurso) {
        for (Curso curso : institucion.getCursos()) {
            if (curso.idExistsInRecursos(idRecurso)) {
                return true;
            }
        }
        return false;
    }






    private void mostrarAlerta(String titulo, String mensaje) {
        Alert alerta = new Alert(Alert.AlertType.INFORMATION);
        alerta.setTitle(titulo);
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }

    private void limpiarCampos() {
        textFieldRutProfesor.clear();
        textFieldIdCurso.clear();
        textFieldIdRecurso.clear();
        textFieldNombreRecurso.clear();
        textFieldDescripcion.clear();
    }

    private void openWindow(String fxmlFile, String title, Button button) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = fxmlLoader.load();
            Stage stage = new Stage();
            Object controller = fxmlLoader.getController();
            if (controller instanceof RecursoController) {
                ((RecursoController) controller).setInstitucion(institucion);
            }
            stage.setTitle(title);
            stage.setScene(new Scene(root));
            stage.show();

            Stage currentStage = (Stage) button.getScene().getWindow();
            currentStage.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}