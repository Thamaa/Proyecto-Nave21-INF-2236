package com.example.proyectosia_aulavirtual;
import java.io.IOException;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class MostrarAlumnosController {
    private Institucion institucion;
    
    public void setInstitucion(Institucion institucion) {
        this.institucion = institucion;
        mostrarAlumnos();

    }


    @FXML
    private Button btnVolverMenuAlumno;

    @FXML
    private TableView<Alumno> tablaAlumnos;

    @FXML
     private TableColumn<Alumno, Integer> columnaCurso;  // Cambiado a Integer para el idCursoPerteneciente

    @FXML
    private TableColumn<Alumno, String> columnaNombre;

    @FXML
    private TableColumn<Alumno, String> columnaApellido;

    @FXML
    private TableColumn<Alumno, String> columnaEdad;

    @FXML
    private TableColumn<Alumno, String> columnaRut;

    private final ObservableList<Alumno> alumnosData = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        // Configurar las columnas
        columnaNombre.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        columnaApellido.setCellValueFactory(new PropertyValueFactory<>("apellido"));
        columnaEdad.setCellValueFactory(new PropertyValueFactory<>("edad"));
        columnaRut.setCellValueFactory(new PropertyValueFactory<>("rut"));
        columnaCurso.setCellValueFactory(new PropertyValueFactory<>("idCursoPerteneciente"));

        // Añadir los datos a la tabla
        tablaAlumnos.setItems(alumnosData);


        btnVolverMenuAlumno.setOnMouseEntered(event -> btnVolverMenuAlumno.setStyle("-fx-background-color: #002153;"));
        btnVolverMenuAlumno.setOnMouseExited(event -> btnVolverMenuAlumno.setStyle("-fx-background-color: #1d4e96;"));

        btnVolverMenuAlumno.setOnAction(event -> openWindow("Alumno.fxml", "Menú Alumno", btnVolverMenuAlumno));
        mostrarAlumnos();
    }

    public void mostrarAlumnos() {
        if (institucion != null) {
            for (Curso curso : institucion.getCursos()) {
                for (Alumno alumno : curso.getAlumnos()) {
                    alumnosData.add(alumno);
                }
            }
        }
    }

    private void openWindow(String fxmlFile, String title, Button button) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = fxmlLoader.load();
            Stage stage = new Stage();
            Object controller = fxmlLoader.getController();
            if (controller instanceof AlumnoController) {
                ((AlumnoController) controller).setInstitucion(institucion);
            }
            stage.setTitle(title);
            stage.setScene(new Scene(root));
            stage.show();

            Stage currentStage = (Stage) button.getScene().getWindow();
            currentStage.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    
    
}
