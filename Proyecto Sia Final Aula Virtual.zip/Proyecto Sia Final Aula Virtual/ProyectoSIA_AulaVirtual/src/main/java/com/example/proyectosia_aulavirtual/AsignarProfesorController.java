package com.example.proyectosia_aulavirtual;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class AsignarProfesorController {
    private Institucion institucion;

    public void setInstitucion(Institucion institucion) {
        this.institucion = institucion;
        mostrarProfesores();
        mostrarRecursos();
    }

    @FXML
    private Button buttonVolverMenu;

    @FXML
    private Button buttonAsignar;

    @FXML
    private TableView<Recurso> tableViewRecursos;

    @FXML
    private TableColumn<Recurso, Integer> columnNombreRecurso;

    @FXML
    private TableColumn<Recurso, String> columNombreR;

    @FXML
    private TableView<Profesor> tableViewProfesores;

    @FXML
    private TableColumn<Profesor, String> columnNombreProfesor;

    @FXML
    private TableColumn<Profesor, String> columnApellidoProfesor;

    @FXML
    private TableColumn<Profesor, Integer> columnEdadProfesor;

    @FXML
    private TableColumn<Profesor, String> columnRutProfesor;

    @FXML
    private TextField textFieldRutProfesor;

    @FXML
    private TextField textFieldIdRecurso;

    private ObservableList<Recurso> recursosSinProfesorList = FXCollections.observableArrayList();

    private ObservableList<Profesor> profesoresList = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        buttonAsignar.setOnMouseEntered(event -> buttonAsignar.setStyle("-fx-background-color: #002153;"));
        buttonVolverMenu.setOnMouseExited(event -> buttonVolverMenu.setStyle("-fx-background-color: #1d4e96;"));
        buttonVolverMenu.setOnMouseEntered(event -> buttonVolverMenu.setStyle("-fx-background-color: #002153;"));
        buttonAsignar.setOnMouseExited(event -> buttonAsignar.setStyle("-fx-background-color: #1d4e96;"));

        columnNombreRecurso.setCellValueFactory(new PropertyValueFactory<>("recursoID"));
        columNombreR.setCellValueFactory(new PropertyValueFactory<>("nombreRecurso"));
        columnNombreProfesor.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        columnApellidoProfesor.setCellValueFactory(new PropertyValueFactory<>("apellido"));
        columnEdadProfesor.setCellValueFactory(new PropertyValueFactory<>("edad"));
        columnRutProfesor.setCellValueFactory(new PropertyValueFactory<>("rut"));
        ObservableList<Recurso> recursosFiltrados = recursosSinProfesorList.filtered(recurso -> recurso.getProfesor() == null);
        tableViewRecursos.setItems(recursosFiltrados);

        tableViewProfesores.setItems(profesoresList);

        buttonVolverMenu.setOnAction(event -> openWindow("Profesor.fxml", "Menú Profesor", buttonVolverMenu));
        buttonAsignar.setOnAction(event -> asignarProfesor());
    }


    private void asignarProfesor() {
        String idRecursoStr = textFieldIdRecurso.getText();
        String rutProfesorStr = textFieldRutProfesor.getText();

        if (idRecursoStr.isEmpty() || rutProfesorStr.isEmpty()) {
            mostrarAlerta("Error", "Por favor, ingrese el ID del recurso y el RUT del profesor.");
            return;
        }

        int idRecurso;
        try {
            idRecurso = Integer.parseInt(idRecursoStr);
        } catch (NumberFormatException e) {
            mostrarAlerta("Error", "El ID del recurso debe ser un número.");
            return;
        }

        Recurso recursoSeleccionado = null;
        for (Recurso recurso : recursosSinProfesorList) {
            if (recurso.getRecursoID() == idRecurso) {
                recursoSeleccionado = recurso;
                break;
            }
        }

        if (recursoSeleccionado == null) {
            mostrarAlerta("Error", "Recurso no encontrado.");
            return;
        }

        Profesor profesorSeleccionado = null;
        for (Profesor profesor : profesoresList) {
            if (profesor.getRut().equals(rutProfesorStr)) {
                profesorSeleccionado = profesor;
                break;
            }
        }

        if (profesorSeleccionado == null) {
            mostrarAlerta("Error", "Profesor no encontrado.");
            return;
        }

        recursoSeleccionado.setProfesor(profesorSeleccionado);
        recursosSinProfesorList.remove(recursoSeleccionado);
        guardarCambiosEnCSV();
        mostrarAlerta("Éxito", "Profesor Asignado Con Éxito");
        textFieldIdRecurso.clear();
        textFieldRutProfesor.clear();
    }
    private void guardarCambiosEnCSV() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("recursos.csv"))) {
            // Escribir el encabezado
            writer.write("ID,Nombre,RutProfesor,DescRec,CursoAlQuePertenece");
            writer.newLine();
            
            // Usar un Set para evitar duplicados
            Set<Integer> idsRecursos = new HashSet<>();

            // Escribir los recursos sin profesor
            for (Recurso recurso : recursosSinProfesorList) {
                if (!idsRecursos.contains(recurso.getRecursoID())) {
                    writer.write(recurso.toCSV());
                    writer.newLine();
                    idsRecursos.add(recurso.getRecursoID());
                }
            }

            // Escribir los recursos con profesor
            for (Curso curso : institucion.getCursos()) {
                for (Recurso recurso : curso.getRecursos()) {
                    if (recurso.getProfesor() != null && !idsRecursos.contains(recurso.getRecursoID())) {
                        writer.write(recurso.toCSV());
                        writer.newLine();
                        idsRecursos.add(recurso.getRecursoID());
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void mostrarAlerta(String titulo, String mensaje) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }


    public void mostrarProfesores(){
        for (Profesor profesor : institucion.getProfesores()) {
            profesoresList.add(profesor);
        }
    }

    private void mostrarRecursos(){
        for(Curso cursos : institucion.getCursos()){
            for(Recurso recurso : cursos.getRecursos()){
                recursosSinProfesorList.add(recurso);
            }
        }
    }






    private void openWindow(String fxmlFile, String title, Button button) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = fxmlLoader.load();
            Stage stage = new Stage();
            Object controller = fxmlLoader.getController();
            if (controller instanceof ProfesorController) {
                ((ProfesorController) controller).setInstitucion(institucion);
            }
            stage.setTitle(title);
            stage.setScene(new Scene(root));
            stage.show();

            Stage currentStage = (Stage) button.getScene().getWindow();
            currentStage.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
