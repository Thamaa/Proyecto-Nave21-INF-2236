package com.example.proyectosia_aulavirtual;
//Se crea una excepción para cuando no se encuentre un recurso
public class RecursoNoEncontradoExcep extends Exception {
    public RecursoNoEncontradoExcep(String mensaje) {
        super(mensaje);
    }
}