package com.example.proyectosia_aulavirtual;

import java.io.IOException;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class HelloApplication extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        Institucion institucion = new Institucion("Technological School ");

        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("MenuPrincipal.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 753, 504);

        if(fxmlLoader.getController() instanceof MenuController){
            ((MenuController) fxmlLoader.getController()).setInstitucion(institucion);
        }
        
        stage.setTitle("AULA VIRTUAL");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args)throws IOException {
        launch();
    }
}