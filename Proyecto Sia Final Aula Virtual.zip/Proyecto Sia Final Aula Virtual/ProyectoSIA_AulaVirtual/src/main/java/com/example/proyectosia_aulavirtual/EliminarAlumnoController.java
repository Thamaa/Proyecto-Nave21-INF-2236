package com.example.proyectosia_aulavirtual;

import java.io.IOException;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import java.io.FileWriter;
import java.io.PrintWriter;
import javafx.scene.control.Alert;


public class EliminarAlumnoController {
    private Institucion institucion;

    @FXML
    private Button btnVolverMenu;

    @FXML
    private Button btnEliminar;

    @FXML
    private TextField txtRutAlumno;

    @FXML
    private TableView<Alumno> tablaAlumnos;

    @FXML
    private TableColumn<Alumno, String> columnaNombre;

    @FXML
    private TableColumn<Alumno, String> columnaApellido;

    @FXML
    private TableColumn<Alumno, String> columnaRut;

    private final ObservableList<Alumno> alumnosData = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        // Configurar las columnas
        columnaNombre.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        columnaApellido.setCellValueFactory(new PropertyValueFactory<>("apellido"));
        columnaRut.setCellValueFactory(new PropertyValueFactory<>("rut"));

        // Cargar los datos desde el archivo CSV


        // Añadir los datos a la tabla
        tablaAlumnos.setItems(alumnosData);

        // Configurar eventos de los botones
        btnEliminar.setOnMouseEntered(event -> btnEliminar.setStyle("-fx-background-color: #002153;"));
        btnEliminar.setOnMouseExited(event -> btnEliminar.setStyle("-fx-background-color: #1d4e96;"));
        btnVolverMenu.setOnMouseEntered(event -> btnVolverMenu.setStyle("-fx-background-color: #002153;"));
        btnVolverMenu.setOnMouseExited(event -> btnVolverMenu.setStyle("-fx-background-color: #1d4e96;"));

        btnEliminar.setOnAction(event -> eliminarAlumno());
        btnVolverMenu.setOnAction(event -> openWindow("Alumno.fxml", "Menú Alumno", btnVolverMenu));
    }

    public void mostrarAlumnos() {
        if (institucion != null) {
            for (Curso curso : institucion.getCursos()) {
                for (Alumno alumno : curso.getAlumnos()) {
                    alumnosData.add(alumno);
                }
            }
        }
    }
//
private void eliminarAlumno() {
    String rutIngresado = txtRutAlumno.getText();
    if (rutIngresado == null || rutIngresado.isEmpty()) {
        mostrarAlerta("Error", "Debe ingresar un RUT.");
        return;
    }

    Alumno alumnoSeleccionado = tablaAlumnos.getSelectionModel().getSelectedItem();
    if (alumnoSeleccionado == null || !alumnoSeleccionado.getRut().equals(rutIngresado)) {
        mostrarAlerta("Error", "Debe seleccionar un alumno que coincida con el RUT ingresado.");
        return;
    }

    try {
        for (Curso curso : institucion.getCursos()) {
            curso.eliminarAlumnoDeCurso(alumnoSeleccionado);
        }
        alumnosData.remove(alumnoSeleccionado);
        tablaAlumnos.refresh();
        actualizarArchivoAlumnos();
        mostrarAlerta("Información", "Alumno eliminado exitosamente.");
    } catch (IOException e) {
        mostrarAlerta("Error", "Ocurrió un error al eliminar el alumno.");
        e.printStackTrace();
    }
}

    private void actualizarArchivoAlumnos() {
        try (PrintWriter pw = new PrintWriter(new FileWriter("alumnos.csv"))) {
            // Escribir la cabecera
            pw.println("Nombre,Apellido,Edad,RUT,CursoID");

            // Escribir los datos actualizados
            for (Alumno alumno : alumnosData) {
                pw.println(alumno.getNombre() + "," + alumno.getApellido() + "," + alumno.getEdad() + "," + alumno.getRut() + "," + alumno.getIdCursoPerteneciente());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

private void mostrarAlerta(String titulo, String mensaje) {
    Alert alert = new Alert(Alert.AlertType.INFORMATION);
    alert.setTitle(titulo);
    alert.setHeaderText(null);
    alert.setContentText(mensaje);
    alert.showAndWait();
}


    private void openWindow(String fxmlFile, String title, Button button) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = fxmlLoader.load();
            Stage stage = new Stage();
            Object controller = fxmlLoader.getController();
            if (controller instanceof AlumnoController) {
                ((AlumnoController) controller).setInstitucion(institucion);
            }
            stage.setTitle(title);
            stage.setScene(new Scene(root));
            stage.show();

            Stage currentStage = (Stage) button.getScene().getWindow();
            currentStage.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void setInstitucion(Institucion institucion) {
        this.institucion = institucion;
        mostrarAlumnos();
    }
}