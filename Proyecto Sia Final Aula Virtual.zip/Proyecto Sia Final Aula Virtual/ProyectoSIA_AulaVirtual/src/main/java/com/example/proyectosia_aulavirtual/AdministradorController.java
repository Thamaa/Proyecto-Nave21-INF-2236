package com.example.proyectosia_aulavirtual;

import java.io.IOException;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class AdministradorController {
    private Institucion institucion;


    @FXML
    private Button opCurso;

    @FXML
    private Button opProfesor;

    @FXML
    private Button opRecurso;

    @FXML
    private Button opAlumnos;

    @FXML
    private Button opVolver;

    @FXML
    public void initialize() {
        opCurso.setOnMouseEntered(event -> opCurso.setStyle("-fx-background-color: #002153;"));
        opProfesor.setOnMouseEntered(event -> opProfesor.setStyle("-fx-background-color: #002153;"));
        opRecurso.setOnMouseEntered(event -> opRecurso.setStyle("-fx-background-color: #002153;"));
        opAlumnos.setOnMouseEntered(event -> opAlumnos.setStyle("-fx-background-color: #002153;"));
        opVolver.setOnMouseEntered(event -> opVolver.setStyle("-fx-background-color: #002153;"));

        opCurso.setOnMouseExited(event -> opCurso.setStyle("-fx-background-color: #003380;"));
        opProfesor.setOnMouseExited(event -> opProfesor.setStyle("-fx-background-color: #003380;"));
        opRecurso.setOnMouseExited(event -> opRecurso.setStyle("-fx-background-color: #003380;"));
        opAlumnos.setOnMouseExited(event -> opAlumnos.setStyle("-fx-background-color: #003380;"));
        opVolver.setOnMouseExited(mouseEvent -> opVolver.setStyle("-fx-background-color: #003380;"));

        opCurso.setOnAction(event -> openWindow("Curso.fxml", "Ventana Curso", opCurso));
        opProfesor.setOnAction(event -> openWindow("Profesor.fxml", "Ventana Profesor", opProfesor));
        opRecurso.setOnAction(event -> openWindow("Recurso.fxml", "Ventana Recurso", opRecurso));
        opAlumnos.setOnAction(event -> openWindow("Alumno.fxml", "Ventana Alumnos", opAlumnos));

        opVolver.setOnAction(event -> openWindow("MenuPrincipal.fxml", "Menú Principal", opVolver));
    }

    private void openWindow(String fxmlFile, String title, Button button) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = fxmlLoader.load();
            Stage stage = new Stage();
            Object controller = fxmlLoader.getController();
             if (controller instanceof ProfesorController) {
                ((ProfesorController) controller).setInstitucion(institucion);
            } else if (controller instanceof CursoController) {
                ((CursoController) controller).setInstitucion(institucion);
            } else if (controller instanceof AlumnoController) {
                ((AlumnoController) controller).setInstitucion(institucion);
            } else if(controller instanceof RecursoController){
                ((RecursoController) controller).setInstitucion(institucion);
            }
            stage.setTitle(title);
            stage.setScene(new Scene(root));
            stage.show();

            Stage currentStage = (Stage) button.getScene().getWindow();
            currentStage.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void setInstitucion(Institucion institucion) {
        this.institucion = institucion;
    }
}
