package com.example.proyectosia_aulavirtual;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class CSVUtil {
    public static void appendToCSV(String fileName, String data) throws IOException {
        try (FileWriter writer = new FileWriter(fileName, true)) {
            writer.append(data);
            writer.append("\n");
        }
    }

    public static void createCSVIfNotExists(String fileName, String header) throws IOException {
        File file = new File(fileName);
        if (!file.exists()) {
            try (FileWriter writer = new FileWriter(fileName)) {
                writer.append(header);
                writer.append("\n");
            }
        }
    }
    public static boolean idExistsInCSV(String fileName, int id) throws IOException {
        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String line;
            br.readLine(); // Saltar la cabecera
            while ((line = br.readLine()) != null) {
                String[] values = line.split(",");
                if (Integer.parseInt(values[0]) == id) {
                    return true;
                }
            }
        }
        return false;
    }

    public static boolean rutExistsInCSV(String fileName, String rut) throws IOException {
        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String line;
            br.readLine(); // Saltar la cabecera
            while ((line = br.readLine()) != null) {
                String[] values = line.split(",");
                if (values[3].equals(rut)) {
                    return true;
                }
            }
        }
        return false;
    }

    public static void actualizarCSV(String filePath, List<String> lines) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            for (String line : lines) {
                writer.write(line);
                writer.newLine();
            }
        }
    }
}