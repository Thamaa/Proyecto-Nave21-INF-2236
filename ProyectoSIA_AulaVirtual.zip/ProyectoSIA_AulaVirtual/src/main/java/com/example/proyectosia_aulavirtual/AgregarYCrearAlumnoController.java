package com.example.proyectosia_aulavirtual;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

//CLASE CASI LISTA (NO ACTUALIZA LA TABLA)

public class AgregarYCrearAlumnoController {
    private Institucion institucion;

    @FXML
    private TextField txtNombre;

    @FXML
    private TextField txtApellido;

    @FXML
    private TextField txtEdad;

    @FXML
    private TextField txtRut;

    @FXML
    private TextField txtCursoID;

    @FXML
    private TableView<Curso> tablaCursos;

    @FXML
    private TableColumn<Curso, Integer> columnaID;

    @FXML
    private TableColumn<Curso, String> columnaNombre;

    @FXML
    private Button btnAgregar;

    @FXML
    private Button btnVolverMenu;

    private final ObservableList<Curso> cursosData = FXCollections.observableArrayList();
    private final ObservableList<Alumno> alumnosData = FXCollections.observableArrayList();  // Alumnos cargados en memoria

    @FXML
    public void initialize() {
        columnaID.setCellValueFactory(new PropertyValueFactory<>("cursoId"));
        columnaNombre.setCellValueFactory(new PropertyValueFactory<>("nombre"));

        tablaCursos.setItems(cursosData);
        btnAgregar.setOnMouseEntered(event -> btnAgregar.setStyle("-fx-background-color: #002153;"));
        btnAgregar.setOnMouseExited(event -> btnAgregar.setStyle("-fx-background-color: #1d4e96;"));
        btnVolverMenu.setOnMouseEntered(event -> btnVolverMenu.setStyle("-fx-background-color: #002153;"));
        btnVolverMenu.setOnMouseExited(event -> btnVolverMenu.setStyle("-fx-background-color: #1d4e96;"));
        btnAgregar.setOnAction(event -> agregarAlumno());
        btnVolverMenu.setOnAction(event -> openWindow("Alumno.fxml", "Menú Alumno", btnVolverMenu));
    }

    public void cargarCursos() {
        cursosData.addAll(institucion.getCursos());
    }

    private boolean cursoIdExisteEnMemoria(int cursoId) {
        return institucion.getCursos().stream().anyMatch(curso -> curso.getCursoId() == cursoId);
    }

    private boolean rutExisteEnMemoria(String rut) {
        return institucion.getAlumnosDesdeCurso().stream().anyMatch(alumno -> alumno.getRut().equals(rut));
    }

    private void agregarAlumno() {
        if (!camposCompletos()) {
            mostrarAlerta("Debe completar todos los campos para poder agregar al alumno");
            return;
        }

        String nombre = txtNombre.getText();
        String apellido = txtApellido.getText();
        int edad = Integer.parseInt(txtEdad.getText());
        String rut = txtRut.getText();
        int cursoId = Integer.parseInt(txtCursoID.getText());

        if (!cursoIdExisteEnMemoria(cursoId)) {
            mostrarAlerta("El curso no existe");
            txtCursoID.clear();
            return;
        }

        if (rutExisteEnMemoria(rut)) {
            mostrarAlerta("Ya existe un alumno con este rut");
            return;
        }

        // Crear el nuevo alumno
        Alumno nuevoAlumno = new Alumno(nombre, apellido, edad, rut, cursoId);

        // Verifica si la lista de alumnos no es nula y lo agrega
        List<Alumno> listaAlumnos = institucion.getAlumnosDesdeCurso();
        if (listaAlumnos != null) {
            listaAlumnos.add(nuevoAlumno);  // Agregar a la memoria
            alumnosData.add(nuevoAlumno);   // Agregar a la lista observable para la TableView (si es necesario)
        } else {
            mostrarAlerta("Error al acceder a la lista de alumnos en memoria.");
            return;
        }

        // Actualizar la TableView (si hay una)
        tablaCursos.refresh();

        // Guardar en el CSV
        try {
            agregarAlumnoACSV(nuevoAlumno);
        } catch (IOException e) {
            e.printStackTrace();
            mostrarAlerta("Error al guardar el alumno en el archivo CSV");
            return;
        }

        mostrarAlerta("Alumno agregado correctamente");
        limpiarCampos();
    }

    private void agregarAlumnoACSV(Alumno alumno) throws IOException {
        // Escribir el alumno en el archivo CSV
        try (FileWriter writer = new FileWriter("alumnos.csv", true);
             BufferedWriter bw = new BufferedWriter(writer);
             PrintWriter out = new PrintWriter(bw)) {
            out.println(alumno.toCSV());
        }
    }


    private boolean camposCompletos() {
        return !txtNombre.getText().trim().isEmpty() &&
                !txtApellido.getText().trim().isEmpty() &&
                !txtEdad.getText().trim().isEmpty() &&
                !txtRut.getText().trim().isEmpty() &&
                !txtCursoID.getText().trim().isEmpty();
    }

    private void mostrarAlerta(String mensaje) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Información");
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }

    private void limpiarCampos() {
        txtNombre.clear();
        txtApellido.clear();
        txtEdad.clear();
        txtRut.clear();
        txtCursoID.clear();
    }

    private void openWindow(String fxmlFile, String title, Button button) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = fxmlLoader.load();
            Stage stage = new Stage();
            Object controller = fxmlLoader.getController();
            if (controller instanceof AlumnoController) {
                ((AlumnoController) controller).setInstitucion(institucion);
            }
            stage.setTitle(title);
            stage.setScene(new Scene(root));
            stage.show();

            Stage currentStage = (Stage) button.getScene().getWindow();
            currentStage.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void setInstitucion(Institucion institucion) {
        this.institucion = institucion;
        cargarCursos();
    }
}
