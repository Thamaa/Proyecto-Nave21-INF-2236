package com.example.proyectosia_aulavirtual;

import java.io.IOException;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class EliminarRecursoController {
    private Institucion institucion;


    @FXML
    private Button btnVolverMenu;

    @FXML
    private Button btnEliminarRecurso;

    @FXML
    private TableView<Recurso> tablaRecursos;

    @FXML
    private TableColumn<Recurso, String> columnaID;

    @FXML
    private TableColumn<Recurso, String> columnaNombre;
    @FXML
    private TableColumn<Recurso, String> columnaIDCurso;

    @FXML
    private TableColumn<Curso, String> columnaNombreCurso;

    @FXML
    private TextField inputRecursoID;

    private ObservableList<Recurso> recursosData = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        //configurar botones
        btnVolverMenu.setOnMouseEntered(event -> btnVolverMenu.setStyle("-fx-background-color: #002153;"));
        btnVolverMenu.setOnMouseExited(event -> btnVolverMenu.setStyle("-fx-background-color: #003380;"));

        btnEliminarRecurso.setOnMouseEntered(event -> btnEliminarRecurso.setStyle("-fx-background-color: #002153;"));
        btnEliminarRecurso.setOnMouseExited(event -> btnEliminarRecurso.setStyle("-fx-background-color:  #003380;"));
        btnVolverMenu.setOnAction(event -> openWindow("Recurso.fxml", "Ventana Recurso", btnVolverMenu));
        btnEliminarRecurso.setOnAction(event -> eliminarRecurso());
        
        //configurar tabla
        columnaID.setCellValueFactory(new PropertyValueFactory<>("recursoID"));
        columnaNombre.setCellValueFactory(new PropertyValueFactory<>("nombreRecurso"));
        columnaIDCurso.setCellValueFactory(new PropertyValueFactory<>("idCursoPerteneciente"));

        tablaRecursos.setItems(recursosData);


    }

    private void mostrarRecursos(){
        for(Curso cursos : institucion.getCursos()){
            for(Recurso recurso : cursos.getRecursos()){
                recursosData.add(recurso);
            }
        }
    }

    //abre ventana anterior 
    private void openWindow(String fxmlFile, String title, Button button) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = fxmlLoader.load();
            Stage stage = new Stage();
            Object controller = fxmlLoader.getController();
            if(controller instanceof RecursoController){
                ((RecursoController) controller).setInstitucion(institucion);
            }
            stage.setTitle(title);
            stage.setScene(new Scene(root));
            stage.show();

            Stage currentStage = (Stage) button.getScene().getWindow();
            currentStage.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //funcion eliminar recurso 
    private void eliminarRecurso() {
    }

    public void setInstitucion(Institucion institucion) {
        this.institucion = institucion;
        mostrarRecursos();
    }
}
