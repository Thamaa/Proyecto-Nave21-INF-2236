package com.example.proyectosia_aulavirtual;
//Se crea la clase Alumno que extiende de la clase Persona
public class Alumno extends Persona {

    private int idCursoPerteneciente;

    //Constructor de la clase Alumno
    public Alumno(String nombre, String apellido, int edad, String rut, int idCursoPerteneciente) {
        super(nombre, apellido, edad, rut);
        this.idCursoPerteneciente = idCursoPerteneciente;
    }
    public String toCSV() {
        return getNombre() + "," + getApellido() + "," + getEdad() + "," + getRut() +"," + getIdCursoPerteneciente();
    }
    //Getters y Setters de la clase Alumno
    public int getIdCursoPerteneciente() {
        return idCursoPerteneciente;
    }

    public void setIdCursoPerteneciente(int idCursoPerteneciente) {
        this.idCursoPerteneciente = idCursoPerteneciente;
    }

}
