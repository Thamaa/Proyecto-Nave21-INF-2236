package com.example.proyectosia_aulavirtual;

import java.io.IOException;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class BuscarCursoController {

    private Institucion institucion;

    @FXML
    private Button opVolver;

    @FXML
    private Button opBuscar;

    @FXML
    private TextField idCursoTextField;

    @FXML
    public void initialize() {
        opVolver.setOnMouseEntered(event -> opVolver.setStyle("-fx-background-color: #002153;"));
        opVolver.setOnMouseExited(event -> opVolver.setStyle("-fx-background-color: #1d4e96;"));
        opVolver.setOnAction(event -> openWindow("Curso.fxml", "Menú Curso", opVolver));

        opBuscar.setOnMouseEntered(event -> opBuscar.setStyle("-fx-background-color: #002153;"));
        opBuscar.setOnMouseExited(event -> opBuscar.setStyle("-fx-background-color: #1d4e96;"));
        opBuscar.setOnAction(event -> buscarCurso());
    }

    public void setInstitucion(Institucion institucion) {
        this.institucion = institucion;
    }

    public void buscarCurso() {
        String cursoIdStr = idCursoTextField.getText();

        try {
            int cursoId = Integer.parseInt(cursoIdStr);

            if (institucion != null) {
                Curso curso = institucion.getCursoById(cursoId);
                if (curso != null) {
                    abrirDetallesCurso(curso);
                } else {
                    mostrarAlerta("Error", "Curso no encontrado.", Alert.AlertType.ERROR);
                }
            } else {
                mostrarAlerta("Error", "Institución no inicializada.", Alert.AlertType.ERROR);
            }
        } catch (NumberFormatException e) {
            mostrarAlerta("Error", "ID del curso inválido.", Alert.AlertType.ERROR);
        }
    }

    private void mostrarAlerta(String titulo, String mensaje, Alert.AlertType tipoAlerta) {
        Alert alerta = new Alert(tipoAlerta);
        alerta.setTitle(titulo);
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }

    private void abrirDetallesCurso(Curso curso) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("DetallesCurso.fxml"));
            Parent root = loader.load();

            // Obtener el controlador de la nueva ventana
            DetallesCursoController detallesController = loader.getController();
            detallesController.setInstitucion(institucion);
            detallesController.setCurso(curso); // Pasar el curso seleccionado

            // Mostrar la nueva ventana
            Stage stage = new Stage();
            stage.setTitle("Detalles del Curso");
            stage.setScene(new Scene(root));
            stage.show();

            // Cerrar la ventana actual
            Stage currentStage = (Stage) opBuscar.getScene().getWindow();
            currentStage.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void openWindow(String fxmlFile, String title, Button button) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = fxmlLoader.load();
            Stage stage = new Stage();
            Object controller = fxmlLoader.getController();
            if(controller instanceof CursoController){
                ((CursoController) controller).setInstitucion(institucion);
            }
            stage.setTitle(title);
            stage.setScene(new Scene(root));
            stage.show();

            Stage currentStage = (Stage) button.getScene().getWindow();
            currentStage.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
