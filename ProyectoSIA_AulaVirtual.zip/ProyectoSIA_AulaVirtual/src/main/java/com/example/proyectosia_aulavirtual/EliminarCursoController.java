package com.example.proyectosia_aulavirtual;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.Optional;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

//CLASE LISTA 

public class EliminarCursoController {
    private Institucion institucion;

    public void setInstitucion(Institucion institucion) {
        this.institucion = institucion;
    }




    @FXML
    private Button btnVolver;

    @FXML
    private Button btnEliminar;

    @FXML
    private TextField txtIdCurso;

    @FXML
    public void initialize() {
        btnVolver.setOnMouseEntered(event -> btnVolver.setStyle("-fx-background-color: #002153;"));
        btnEliminar.setOnMouseEntered(event -> btnEliminar.setStyle("-fx-background-color: #002153;"));

        btnVolver.setOnMouseExited(event -> btnVolver.setStyle("-fx-background-color: #1d4e96;"));
        btnEliminar.setOnMouseExited(event -> btnEliminar.setStyle("-fx-background-color: #1d4e96;"));

        btnVolver.setOnAction(event -> openWindow("Curso.fxml", "Menú Curso", btnVolver));
        btnEliminar.setOnAction(event -> confirmarEliminacionCurso());
    }

    private void confirmarEliminacionCurso() {
        String idCursoStr = txtIdCurso.getText();
        if (idCursoStr.isEmpty()) {
            mostrarAlerta("Error", "Debe ingresar un ID de curso.");
            return;
        }

        int idCurso;
        try {
            idCurso = Integer.parseInt(idCursoStr);
        } catch (NumberFormatException e) {
            mostrarAlerta("Error", "El ID de curso debe ser un número.");
            return;
        }

        Curso curso = institucion.buscarCursoPorId(idCurso);
        if (curso == null) {
            mostrarAlerta("Error", "ID de curso no existe.");
            return;
        }

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmación de eliminación");
        alert.setHeaderText("Recuerda que al eliminar el curso eliminas los alumnos y los recursos asociados a este.");
        alert.setContentText("¿Quieres continuar?");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            eliminarCurso(curso);
            txtIdCurso.clear();
        }
    }

    private void eliminarCurso(Curso curso) {
        try {
            // Eliminar alumnos del curso usando un iterador para que no de error de concurrencia 
            Iterator<Alumno> alumnoIterator = curso.getAlumnos().iterator();
            while (alumnoIterator.hasNext()) {
                Alumno alumno = alumnoIterator.next();
                alumnoIterator.remove();
                curso.eliminarAlumnoDeCurso(alumno);
            }

            // Eliminar recursos del curso usando un iterador
            Iterator<Recurso> recursoIterator = curso.getRecursos().iterator();
            while (recursoIterator.hasNext()) {
                Recurso recurso = recursoIterator.next();
                recursoIterator.remove();
                curso.eliminarRecursoDeCurso(recurso);
            }

            // Eliminar el curso de la memoria
            institucion.eliminarCurso(curso);

            // Actualizar los archivos CSV
            actualizarCSVs();

            mostrarAlerta("Éxito", "Curso eliminado exitosamente.");
        } catch (IOException e) {
            mostrarAlerta("Error", "Ocurrió un error al eliminar el curso.");
            e.printStackTrace();
        }
    }

    private void actualizarCSVs() throws IOException {
        // Actualizar cursos.csv
        try (FileWriter writer = new FileWriter("cursos.csv");
             BufferedWriter bw = new BufferedWriter(writer);
             PrintWriter out = new PrintWriter(bw)) {
            out.println("ID,Nombre");
            for (Curso curso : institucion.getCursos()) {
                out.println(curso.toCSV());
            }
        }

        // Actualizar alumnos.csv
        try (FileWriter writer = new FileWriter("alumnos.csv");
             BufferedWriter bw = new BufferedWriter(writer);
             PrintWriter out = new PrintWriter(bw)) {
            out.println("Nombre,Apellido,Edad,RUT,IdCursoAlQuePertenece");
            for (Curso curso : institucion.getCursos()) {
                for (Alumno alumno : curso.getAlumnos()) {
                    out.println(alumno.toCSV());
                }
            }
        }

        // Actualizar recursos.csv
        try (FileWriter writer = new FileWriter("recursos.csv");
             BufferedWriter bw = new BufferedWriter(writer);
             PrintWriter out = new PrintWriter(bw)) {
            out.println("ID,Nombre,RutProfesor,DescRec,CursoAlQuePertenece");
            for (Curso curso : institucion.getCursos()) {
                for (Recurso recurso : curso.getRecursos()) {
                    out.println(recurso.toCSV());
                }
            }
        }
    }



    private void openWindow(String fxmlFile, String title, Button button) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = fxmlLoader.load();
            Stage stage = new Stage();
            Object controller = fxmlLoader.getController();
            if(controller instanceof CursoController){
                ((CursoController) controller).setInstitucion(institucion);
            }
            stage.setTitle(title);
            stage.setScene(new Scene(root));
            stage.show();

            Stage currentStage = (Stage) button.getScene().getWindow();
            currentStage.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void mostrarAlerta(String titulo, String mensaje) {
        Alert alerta = new Alert(Alert.AlertType.INFORMATION);
        alerta.setTitle(titulo);
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }


}
