package com.example.proyectosia_aulavirtual;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class CrearProfesorController {
    private Institucion institucion;

    @FXML
    private Button buttonVolverMenu;

    @FXML
    private Button buttonCrearProfesor;

    @FXML
    private TextField textFieldNombreProfesor;

    @FXML
    private TextField textFieldApellidoProfesor;

    @FXML
    private TextField textFieldEdadProfesor;

    @FXML
    private TextField textFieldRutProfesor;

    @FXML
    public void initialize() {
        buttonVolverMenu.setOnMouseEntered(event -> buttonVolverMenu.setStyle("-fx-background-color: #3a6aa1;"));
        buttonVolverMenu.setOnMouseExited(event -> buttonVolverMenu.setStyle("-fx-background-color: #1d4e96;"));

        buttonCrearProfesor.setOnMouseEntered(event -> buttonCrearProfesor.setStyle("-fx-background-color: #3a6aa1;"));
        buttonCrearProfesor.setOnMouseExited(event -> buttonCrearProfesor.setStyle("-fx-background-color: #1d4e96;"));

        buttonVolverMenu.setOnAction(event -> openWindow("Profesor.fxml", "Menú Profesor", buttonVolverMenu));
        buttonCrearProfesor.setOnAction(event -> {
            try {
                crearProfesor();
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }

    private void crearProfesor() throws IOException {
        String nombre = textFieldNombreProfesor.getText();
        String apellido = textFieldApellidoProfesor.getText();
        int edad = Integer.parseInt(textFieldEdadProfesor.getText());
        String rut = textFieldRutProfesor.getText();

        if (nombre.isEmpty() || apellido.isEmpty() || textFieldEdadProfesor.getText().isEmpty() || rut.isEmpty()) {
            mostrarAlerta("Error", "Debe completar todos los campos.");
            return;
        }

        if (institucion.rutExisteEnMemoria(rut)) {
            mostrarAlerta("Error", "Ya existe un profesor con este RUT.");
            return;
        }

        Profesor nuevoProfesor = new Profesor(nombre, apellido, edad, rut);
        institucion.agregarProfesor(nuevoProfesor);

        mostrarAlerta("Éxito", "Profesor agregado correctamente.");
        limpiarCampos();
    }

    private void openWindow(String fxmlFile, String title, Button button) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = fxmlLoader.load();
            Stage stage = new Stage();
            Object controller = fxmlLoader.getController();
            if (controller instanceof ProfesorController) {
                ((ProfesorController) controller).setInstitucion(institucion);
            }
            stage.setTitle(title);
            stage.setScene(new Scene(root));
            stage.show();

            Stage currentStage = (Stage) button.getScene().getWindow();
            currentStage.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void setInstitucion(Institucion institucion) {
        this.institucion = institucion;
    }

    private void mostrarAlerta(String titulo, String mensaje) {
        Alert alerta = new Alert(Alert.AlertType.INFORMATION);
        alerta.setTitle(titulo);
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }

    private void limpiarCampos() {
        textFieldNombreProfesor.clear();
        textFieldApellidoProfesor.clear();
        textFieldEdadProfesor.clear();
        textFieldRutProfesor.clear();
    } 
}

