package com.example.proyectosia_aulavirtual;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

//Se crea la clase Curso con sus atributos
public class Curso {
    private int cursoId;
    private String nombre;
    private ArrayList<Recurso> recursos;
    private ArrayList<Alumno> alumnos; 
    private HashMap<String,Alumno> alumnosMap;
//Se crea el constructor de la clase Curso
    public Curso(int cursoId, String nombre) {
        this.cursoId = cursoId;
        this.nombre = nombre;
        recursos = new ArrayList<>();
        alumnos = new ArrayList<>();
        alumnosMap = new HashMap<>();
    }

//Se crean los metodos getter y setter de la clase Curso

    public void setCursoId(int cursoId) {
        this.cursoId = cursoId;
    }

    public int getCursoId(){
        return cursoId;
    }

    public void setNombre(String nombre){
        this.nombre = nombre;
    }

    public String getNombre(){
        return nombre;
    }

    public void setRecursos(ArrayList<Recurso> recursos){
        this.recursos = recursos;
    }

    public ArrayList<Alumno> getAlumnos(){
        return alumnos;
    }

    public void setAlumnos(ArrayList<Alumno> alumnos){
        this.alumnos = alumnos;
    }

    public ArrayList<Recurso> getRecursos() {
        return recursos;
    }

    public void setAlumnosMap(HashMap<String, Alumno> alumnosMap) {
        this.alumnosMap = alumnosMap;
    }


    public HashMap<String, Alumno> getAlumnosMap() {
        return alumnosMap;
    }

    public boolean idExistsInRecursos(int id) {
        for (Recurso recurso : recursos) {
            if (recurso.getRecursoID() == id) {
                return true;
            }
        }
        return false;
    }

    // ***METODOS AGREGAR Y BUSCAR***

    public void agregarRecursoACurso(Recurso recurso) throws IOException {
        // Verificar si el ID ya existe en el archivo CSV
            recursos.add(recurso);

    }

    
    public void agregarAlumnoACurso(Alumno alumno)throws IOException {
        this.alumnos.add(alumno);
        alumnosMap.put(alumno.getRut(), alumno);
    }

    public void agregarRecurso(Recurso recurso) throws IOException {
        recursos.add(recurso);

    }

    public Recurso buscarRecursoPorID(int id) {
        for (Recurso recurso : recursos) {
            if (recurso.getRecursoID() == id) {
                return recurso;
            }
        }
        return null;
    }

    // Método para convertir el objeto a una cadena CSV

    public String toCSV() {
        return cursoId + "," + nombre; 
    }


    public void eliminarProfesorDeRecursos(String rutProfesor) throws IOException {
        for (Recurso recurso : recursos) {
            Profesor profesor = recurso.getProfesor();
            if (profesor != null && profesor.getRut().equals(rutProfesor)) {
                recurso.eliminarProfesor();
            }
        }
        // Actualizar el archivo CSV
        actualizarCSVRecursos();
    }


    public void eliminarAlumnoDeCurso(Alumno alumno) throws IOException {
        alumnos.remove(alumno);
        alumnosMap.remove(alumno.getRut());
    }

    //ELIMINAR RECUSO DE CURSO
    public void eliminarRecursoDeCurso(Recurso recurso){
        recursos.remove(recurso);
    }

    private void actualizarCSVRecursos() throws IOException {
        try (FileWriter writer = new FileWriter("recursos.csv")) {
            writer.append("ID,Nombre,Profesor\n");
            for (Recurso recurso : recursos) {
                writer.append(recurso.toCSV());
                writer.append("\n");
            }
        }
    }

    private void actualizarCSV(String fileName, ArrayList<Alumno> alumnos) throws IOException {
        try (FileWriter writer = new FileWriter(fileName)) {
            writer.append("Nombre,Apellido,Edad,RUT\n");
            for (Alumno alumno : alumnos) {
                writer.append(alumno.toCSV());
                writer.append("\n");
            }
        }
    }

}
