package com.example.proyectosia_aulavirtual;
//Se crea una excepcion para el rut mal formateado
public class RutMalFormateadoExcep extends Exception {
    public RutMalFormateadoExcep(String mensaje){
        super(mensaje);
    }

}
