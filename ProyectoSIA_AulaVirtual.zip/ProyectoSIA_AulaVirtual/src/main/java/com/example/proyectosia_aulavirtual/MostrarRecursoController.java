package com.example.proyectosia_aulavirtual;

import java.io.IOException;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class MostrarRecursoController {

    private Institucion institucion;


    @FXML
    private TableView<Recurso> tablaRecursos;

    @FXML
    private TableColumn<Recurso, Integer> columnaIdRecurso;

    @FXML
    private TableColumn<Recurso, String> columnaNombreRecurso;

    @FXML
    private TableColumn<Recurso, String> columnaRutProfesor;

    @FXML
    private TableColumn<Recurso, String> columnaDescripcion;

    @FXML
    private TableColumn<Recurso, Integer> columnaIdCurso;

    @FXML
    private javafx.scene.control.Button buttonVolverMenuRecurso;

    private final ObservableList<Recurso> recursosData = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        // Configurar las columnas de la tabla
        columnaIdRecurso.setCellValueFactory(new PropertyValueFactory<>("recursoID"));
        columnaNombreRecurso.setCellValueFactory(new PropertyValueFactory<>("nombreRecurso"));
        columnaRutProfesor.setCellValueFactory(new PropertyValueFactory<>("rutProfesor"));
        columnaDescripcion.setCellValueFactory(new PropertyValueFactory<>("descripcionRec"));
        columnaIdCurso.setCellValueFactory(new PropertyValueFactory<>("idCursoPerteneciente"));
        columnaRutProfesor.setCellValueFactory(cellData -> {
            Recurso recurso = cellData.getValue();
            if (recurso.getProfesor() == null) {
                return new SimpleStringProperty("0");
            } else {
                return new SimpleStringProperty(recurso.getProfesor().getRut());
            }
        });

        buttonVolverMenuRecurso.setOnMouseEntered(event -> buttonVolverMenuRecurso.setStyle("-fx-background-color: #002153;"));
        buttonVolverMenuRecurso.setOnMouseExited(event -> buttonVolverMenuRecurso.setStyle("-fx-background-color: #003380;"));
        buttonVolverMenuRecurso.setOnAction(event -> openWindow("Recurso.fxml", "Ventana Recurso", buttonVolverMenuRecurso));
        // Cargar los datos desde el archivo CSV


        // Añadir los datos a la tabla
        tablaRecursos.setItems(recursosData);
    }

    private void mostrarRecursos(){
        for(Curso cursos : institucion.getCursos()){
            for(Recurso recurso : cursos.getRecursos()){
                recursosData.add(recurso);
            }
        }
    }


        private void openWindow(String fxmlFile, String title, Button button) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = fxmlLoader.load();
            Stage stage = new Stage();
            Object controller = fxmlLoader.getController();
            if(controller instanceof RecursoController){
                ((RecursoController) controller).setInstitucion(institucion);
            }
            stage.setTitle(title);
            stage.setScene(new Scene(root));
            stage.show();

            Stage currentStage = (Stage) button.getScene().getWindow();
            currentStage.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void setInstitucion(Institucion institucion) {
        this.institucion = institucion;
        mostrarRecursos();
    }
}