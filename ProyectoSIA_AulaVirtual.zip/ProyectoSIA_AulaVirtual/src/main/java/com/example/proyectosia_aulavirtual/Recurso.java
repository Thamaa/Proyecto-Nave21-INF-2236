package com.example.proyectosia_aulavirtual;

//Se crea la clase Recurso con sus respectivos atributos
public class Recurso {
    private String nombreRecurso;
    private String descripcionRec;
    private int recursoID;
    private Profesor profesor;
    private int idCursoPerteneciente;

//Se crea el constructor de la clase Recurso
    public Recurso(String nombreRecurso,String descripcionRec, int RecursoID, Profesor profesor,int cursoPerteneciente){
        this.nombreRecurso = nombreRecurso;
        this.recursoID = RecursoID;
        this.descripcionRec = descripcionRec;
        this.profesor = profesor;
        this.idCursoPerteneciente = cursoPerteneciente;

    }
//Se crea el constructor de la clase Recurso con 4 parametros
    public Recurso(int idRecurso, String nombreRecurso, String desc, int cursoId) {
        this.recursoID = idRecurso;
        this.nombreRecurso = nombreRecurso;
        this.descripcionRec = desc;
        this.idCursoPerteneciente = cursoId;
    }
//Se crea el constructor de la clase Recurso con 2 parametros
    public Recurso(String id, String nombre){

        this.recursoID = Integer.parseInt(id);
        this.nombreRecurso = nombre;

    }


//Se crean los metodos getter y set de los atributos de la clase Recurso
    public void setProfesor(Profesor profesor){
        this.profesor = profesor;
    }

    public void setRecursoID(int RecursoID){
        this.recursoID = RecursoID;
    }

    public int getRecursoID(){
        return recursoID;
    }

    public void setDescripcionRec(String descripcionRec){
        this.descripcionRec = descripcionRec;
    }

    public String getDescripcionRec(){
        return descripcionRec;
    }

    public void agregarProfesorARecurso(Profesor profesor){
        this.profesor = profesor;
    }

    public Profesor getProfesor(){
        return profesor;
    }

    public void setNombreRecurso(String nombreRecurso) {
        this.nombreRecurso = nombreRecurso;
    }

    public String getNombreRecurso(){
        return nombreRecurso;
    }
    
    public void eliminarProfesor() {
        this.profesor = null;
    }

    public String toCSV() {
        String rutProfesor = (profesor != null) ? profesor.getRut() : "0";
        return recursoID + "," + nombreRecurso + "," + rutProfesor + "," + descripcionRec + "," + idCursoPerteneciente;
    }

    

    public int getIdCursoPerteneciente() {
        return idCursoPerteneciente;
    }

    public void setIdCursoPerteneciente(int cursoPerteneciente) {
        this.idCursoPerteneciente = cursoPerteneciente;
    }

    public Profesor getProfesorPorRut(String rut) {
        if(profesor != null && profesor.getRut().equals(rut)){
            return this.profesor;
        }
        return null;
    }
}



