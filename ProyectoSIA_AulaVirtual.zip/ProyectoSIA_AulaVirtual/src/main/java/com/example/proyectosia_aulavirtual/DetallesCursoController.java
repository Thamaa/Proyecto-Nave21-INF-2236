package com.example.proyectosia_aulavirtual;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;

public class DetallesCursoController {
    private Institucion institucion;
    private Curso cursoSeleccionado;

    @FXML
    private Button opVolver;

    @FXML
    private Label labelTechnological;

    @FXML
    private Label labelBuscarCurso;

    @FXML
    private Label labelAulaVirtual;

    @FXML
    private TableView<Curso> tableCursos;

    @FXML
    private TableColumn<Curso, Integer> colID;

    @FXML
    private TableColumn<Curso, String> colNombre;

    @FXML
    private TableColumn<Curso, String> colAlumnos;

    private ObservableList<Curso> cursosList;

    @FXML
    public void initialize() {
        // Configuración de las columnas de la tabla
        colID.setCellValueFactory(new PropertyValueFactory<>("cursoId"));
        colNombre.setCellValueFactory(new PropertyValueFactory<>("nombre"));

        // Configuración de la columna de alumnos para mostrar los nombres y apellidos uno debajo del otro
        colAlumnos.setCellValueFactory(curso -> {
            StringBuilder alumnosStr = new StringBuilder();
            for (Alumno alumno : curso.getValue().getAlumnos()) {
                alumnosStr.append(alumno.getNombre())
                        .append(" ")
                        .append(alumno.getApellido())
                        .append("\n");  // Saltos de línea entre cada nombre y apellido
            }
            return new javafx.beans.property.SimpleStringProperty(alumnosStr.toString());
        });

        // Inicializar la lista observable de cursos
        cursosList = FXCollections.observableArrayList();
        tableCursos.setItems(cursosList);

        // Estilos para el botón de volver
        opVolver.setOnMouseEntered(event -> opVolver.setStyle("-fx-background-color: #002153;"));
        opVolver.setOnMouseExited(event -> opVolver.setStyle("-fx-background-color: #1d4e96;"));
        opVolver.setOnAction(event -> openWindow("Curso.fxml", "Menú Curso", opVolver));
    }

    public void setInstitucion(Institucion institucion) {
        this.institucion = institucion;
    }

    public void setCurso(Curso curso) {
        this.cursoSeleccionado = curso;
        mostrarDetallesCurso();
    }

    private void mostrarDetallesCurso() {
        if (cursoSeleccionado != null) {
            cursosList.setAll(cursoSeleccionado);
        }
    }

    private void openWindow(String fxmlFile, String title, Button button) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = fxmlLoader.load();
            Stage stage = new Stage();
            Object controller = fxmlLoader.getController();
            if(controller instanceof CursoController){
                ((CursoController) controller).setInstitucion(institucion);
            }
            stage.setTitle(title);
            stage.setScene(new Scene(root));
            stage.show();

            Stage currentStage = (Stage) button.getScene().getWindow();
            currentStage.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
