package com.example.proyectosia_aulavirtual;

import java.io.IOException;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class MostrarProfesoresController {

    private Institucion institucion;

    @FXML
    private TableView<Profesor> tablaProfesores;

    @FXML
    private TableColumn<Profesor, String> columnaNombre;

    @FXML
    private TableColumn<Profesor, String> columnaApellido;

    @FXML
    private TableColumn<Profesor, String> columnaRut;

    @FXML
    private TableColumn<Profesor, String> columnaEdad;

    @FXML
    private Button buttonVolverMenu;

    private final ObservableList<Profesor> profesoresData = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        // Configurar las columnas
        columnaNombre.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        columnaApellido.setCellValueFactory(new PropertyValueFactory<>("apellido"));
        columnaEdad.setCellValueFactory(new PropertyValueFactory<>("edad"));
        columnaRut.setCellValueFactory(new PropertyValueFactory<>("rut"));


        // Añadir los datos a la tabla
        tablaProfesores.setItems(profesoresData);

        buttonVolverMenu.setOnMouseEntered(event -> buttonVolverMenu.setStyle("-fx-background-color: #002153;"));
        buttonVolverMenu.setOnMouseExited(event -> buttonVolverMenu.setStyle("-fx-background-color: #1d4e96;"));

        buttonVolverMenu.setOnAction(event -> openWindow("Profesor.fxml", "Menú Profesor", buttonVolverMenu));
    }

    public void mostrarProfesores(){
        for (Profesor profesor : institucion.getProfesores()) {
            profesoresData.add(profesor);
        }
    }

    private void openWindow(String fxmlFile, String title, Button button) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = fxmlLoader.load();
            Stage stage = new Stage();
            Object controller = fxmlLoader.getController();
            if (controller instanceof ProfesorController) {
                ((ProfesorController) controller).setInstitucion(institucion);
            }
            stage.setTitle(title);
            stage.setScene(new Scene(root));
            stage.show();

            Stage currentStage = (Stage) button.getScene().getWindow();
            currentStage.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public void setInstitucion(Institucion institucion) {
        this.institucion = institucion;
        mostrarProfesores();
    }
}