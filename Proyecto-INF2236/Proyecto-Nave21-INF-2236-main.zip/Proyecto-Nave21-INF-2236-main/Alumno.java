public class Alumno extends Persona {


    public Alumno(String nombre, String apellido, int edad, String rut) {
        super(nombre, apellido, edad, rut);

    }

}
