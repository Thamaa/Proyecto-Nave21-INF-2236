public class Profesor extends Persona {
    public Profesor(String nombre, String apellido, int edad, String rut) {
        super(nombre, apellido, edad, rut);
    }
}
