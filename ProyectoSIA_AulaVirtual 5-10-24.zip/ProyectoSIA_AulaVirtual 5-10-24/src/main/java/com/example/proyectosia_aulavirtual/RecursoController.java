package com.example.proyectosia_aulavirtual;

import java.io.IOException;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class RecursoController {
    private Institucion institucion;

    @FXML
    private Button btnAgregarRecurso;

    @FXML
    private Button btnEliminarRecurso;

    @FXML
    private Button btnMostrarRecursos;

    @FXML
    private Button btnVolverMenu;

    @FXML
    public void initialize() {
        btnAgregarRecurso.setOnMouseEntered(event -> btnAgregarRecurso.setStyle("-fx-background-color: #002153;"));
        btnAgregarRecurso.setOnMouseExited(event -> btnAgregarRecurso.setStyle("-fx-background-color: #1d4e96;"));

        btnEliminarRecurso.setOnMouseEntered(event -> btnEliminarRecurso.setStyle("-fx-background-color: #002153;"));
        btnEliminarRecurso.setOnMouseExited(event -> btnEliminarRecurso.setStyle("-fx-background-color: #1d4e96;"));

        btnMostrarRecursos.setOnMouseEntered(event -> btnMostrarRecursos.setStyle("-fx-background-color: #002153;"));
        btnMostrarRecursos.setOnMouseExited(event -> btnMostrarRecursos.setStyle("-fx-background-color: #1d4e96;"));

        btnVolverMenu.setOnMouseEntered(event -> btnVolverMenu.setStyle("-fx-background-color: #002153;"));
        btnVolverMenu.setOnMouseExited(event -> btnVolverMenu.setStyle("-fx-background-color: #1d4e96;"));

        btnAgregarRecurso.setOnAction(event -> openWindow("agregarRecursoACursoF.fxml", "Agregar Recurso", btnAgregarRecurso));
        btnEliminarRecurso.setOnAction(event -> openWindow("eliminarRecursoDeCursoPT2.fxml", "Eliminar Recurso", btnEliminarRecurso));
        btnMostrarRecursos.setOnAction(event -> openWindow("MostrarRecurso.fxml", "Mostrar Recursos", btnMostrarRecursos));
        btnVolverMenu.setOnAction(event -> openWindow("MenuPrincipal.fxml", "Menú Principal", btnVolverMenu));
    }

    private void openWindow(String fxmlFile, String title, Button button) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = fxmlLoader.load();
            Stage stage = new Stage();
            Object controller = fxmlLoader.getController();
            if (controller instanceof AgregarRecursoController) {
                ((AgregarRecursoController) controller).setInstitucion(institucion);
            } else if (controller instanceof MostrarRecursoController) {
                ((MostrarRecursoController) controller).setInstitucion(institucion);
            } else if (controller instanceof EliminarRecursoController) {
                ((EliminarRecursoController) controller).setInstitucion(institucion);
            } else if (controller instanceof MenuController) {
                ((MenuController) controller).setInstitucion(institucion);
            }
            stage.setTitle(title);
            stage.setScene(new Scene(root));
            stage.show();

            // Cerrar la ventana actual
            Stage currentStage = (Stage) button.getScene().getWindow();
            currentStage.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void setInstitucion(Institucion institucion) {
        this.institucion = institucion;
    }
}
