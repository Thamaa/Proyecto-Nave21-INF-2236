package com.example.proyectosia_aulavirtual;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class EliminarProfesorController {
    private Institucion institucion;

    public void setInstitucion(Institucion institucion) {
        this.institucion = institucion;
        mostrarProfesores();
    }

    @FXML
    private TableView<Profesor> tableViewProfesores;

    @FXML
    private TableColumn<Profesor, String> columnNombreProfesor;

    @FXML
    private TableColumn<Profesor, String> columnRutProfesor;

    @FXML
    private Button buttonVolverMenu;

    @FXML
    private Button buttonEliminarProfesor;

    @FXML
    private TextField textFieldRutProfesor;

    private final ObservableList<Profesor> profesoresData = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        columnNombreProfesor.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        columnRutProfesor.setCellValueFactory(new PropertyValueFactory<>("rut"));
        tableViewProfesores.setItems(profesoresData);

        buttonVolverMenu.setOnMouseEntered(event -> buttonVolverMenu.setStyle("-fx-background-color: #002153;"));
        buttonVolverMenu.setOnMouseExited(event -> buttonVolverMenu.setStyle("-fx-background-color: #1d4e96;"));
        buttonVolverMenu.setOnAction(event -> openWindow("Profesor.fxml", "Menú Profesor", buttonVolverMenu));

        buttonEliminarProfesor.setOnMouseEntered(event -> buttonEliminarProfesor.setStyle("-fx-background-color: #002153;"));
        buttonEliminarProfesor.setOnMouseExited(event -> buttonEliminarProfesor.setStyle("-fx-background-color: #1d4e96;"));
        buttonEliminarProfesor.setOnAction(event -> eliminarProfesor());
    }

    private void eliminarProfesor() {
        String rutProfesor = textFieldRutProfesor.getText();
        if (rutProfesor == null || rutProfesor.isEmpty()) {
            mostrarAlerta("Error", "Debe ingresar un RUT.");
            return;
        }

        try {
            // Eliminar profesor de los recursos
            for (Curso curso : institucion.getCursos()) {
                curso.eliminarProfesorDeRecursos(rutProfesor);
            }

            // Eliminar profesor de la memoria
            institucion.eliminarProfesor(rutProfesor);

            // Actualizar los archivos CSV
            actualizarCSVs();

            mostrarAlerta("Éxito", "Profesor eliminado exitosamente.");
        } catch (IOException e) {
            mostrarAlerta("Error", "Ocurrió un error al eliminar el profesor.");
            e.printStackTrace();
        }
    }

    private void actualizarCSVs() throws IOException {
        // Actualizar cursos.csv
        try (FileWriter writer = new FileWriter("cursos.csv");
             BufferedWriter bw = new BufferedWriter(writer);
             PrintWriter out = new PrintWriter(bw)) {
            out.println("ID,Nombre");
            for (Curso curso : institucion.getCursos()) {
                out.println(curso.toCSV());
            }
        }

        // Actualizar alumnos.csv
        try (FileWriter writer = new FileWriter("alumnos.csv");
             BufferedWriter bw = new BufferedWriter(writer);
             PrintWriter out = new PrintWriter(bw)) {
            out.println("Nombre,Apellido,Edad,RUT,IdCursoAlQuePertenece");
            for (Curso curso : institucion.getCursos()) {
                for (Alumno alumno : curso.getAlumnos()) {
                    out.println(alumno.toCSV());
                }
            }
        }

        // Actualizar recursos.csv
        try (FileWriter writer = new FileWriter("recursos.csv");
             BufferedWriter bw = new BufferedWriter(writer);
             PrintWriter out = new PrintWriter(bw)) {
            out.println("ID,Nombre,RutProfesor,DescRec,CursoAlQuePertenece");
            for (Curso curso : institucion.getCursos()) {
                for (Recurso recurso : curso.getRecursos()) {
                    out.println(recurso.toCSV());
                }
            }
        }

        // Actualizar profesores.csv
        try (FileWriter writer = new FileWriter("profesores.csv");
             BufferedWriter bw = new BufferedWriter(writer);
             PrintWriter out = new PrintWriter(bw)) {
            out.println("Nombre,Apellido,Edad,RUT");
            for (Profesor profesor : institucion.getProfesores()) {
                out.println(profesor.toCSV());
            }
        }
    }

    private void openWindow(String fxmlFile, String title, Button button) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = fxmlLoader.load();
            Stage stage = new Stage();
            Object controller = fxmlLoader.getController();
            if (controller instanceof ProfesorController) {
                ((ProfesorController) controller).setInstitucion(institucion);
            }
            stage.setTitle(title);
            stage.setScene(new Scene(root));
            stage.show();

            Stage currentStage = (Stage) button.getScene().getWindow();
            currentStage.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    private void mostrarAlerta(String titulo, String mensaje) {
        Alert alerta = new Alert(Alert.AlertType.INFORMATION);
        alerta.setTitle(titulo);
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }

    public void mostrarProfesores(){
        for (Profesor profesor : institucion.getProfesores()) {
            profesoresData.add(profesor);
        }
    }
}